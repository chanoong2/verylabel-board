/* VL 영입보드 확장: 인스타 데이터 가져오기 + 영입보드 서버 호출 */
var DEFAULT_API = 'https://script.google.com/macros/s/AKfycbw17fSf5NT_tr51X9KDS3xjUd-1cfTdRbmMKlQ3--cP7YvNa46Ut4VndML4Q4prXfFx/exec';
var DEFAULT_APP = 'https://chanoong2.github.io/verylabel-board/';
var lastIg = 0;
function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
async function igGap() { var w = lastIg + 2500 - Date.now(); if (w > 0) await sleep(w); lastIg = Date.now(); }
function pick(u) {
  var media = (u.edge_owner_to_timeline_media && u.edge_owner_to_timeline_media.edges) || [];
  return {
    username: u.username, name: u.full_name || '', bio: u.biography || '',
    followers: u.edge_followed_by ? u.edge_followed_by.count : '', following: u.edge_follow ? u.edge_follow.count : '',
    posts: u.edge_owner_to_timeline_media ? u.edge_owner_to_timeline_media.count : '',
    category: u.category_name || u.business_category_name || '', email: u.business_email || '', phone: u.business_phone_number || '',
    ext: u.external_url || (u.bio_links && u.bio_links[0] ? u.bio_links[0].url : ''),
    isBusiness: !!u.is_business_account, isProfessional: !!u.is_professional_account, isPrivate: !!u.is_private, isVerified: !!u.is_verified,
    items: media.slice(0, 12).map(function (e) { var n = e.node || {}; return {
      likes: n.edge_liked_by ? n.edge_liked_by.count : (n.edge_media_preview_like ? n.edge_media_preview_like.count : 0),
      comments: n.edge_media_to_comment ? n.edge_media_to_comment.count : 0, ts: n.taken_at_timestamp || 0,
      caption: (n.edge_media_to_caption && n.edge_media_to_caption.edges[0] ? n.edge_media_to_caption.edges[0].node.text : '').slice(0, 600),
      views: n.video_view_count || 0, paid: !!n.is_paid_partnership }; })
  };
}
async function analyze(handle) {
  var h = String(handle || '').toLowerCase().replace(/^@/, '').replace(/[^a-z0-9._]/g, '');
  if (!h) return { kind: 'none' };
  var key = 'c_' + h, c = await chrome.storage.local.get(key);
  if (c[key] && Date.now() - c[key].at < 6 * 3600e3) return c[key].raw;
  var raw = null;
  try {
    await igGap();
    var r = await fetch('https://www.instagram.com/api/v1/users/web_profile_info/?username=' + encodeURIComponent(h), { headers: { 'x-ig-app-id': '936619743392459' }, credentials: 'include' });
    if (r.status === 404) raw = { kind: 'none', notFound: true };
    else if (r.ok) { var j = await r.json(); if (j && j.data && j.data.user) raw = { kind: 'api', user: pick(j.data.user) }; }
  } catch (e) {}
  if (!raw) {
    try {
      await igGap();
      var r2 = await fetch('https://www.instagram.com/' + encodeURIComponent(h) + '/', { credentials: 'include' });
      var t = await r2.text();
      var m = t.match(/<meta[^>]*name="description"[^>]*content="([^"]*)"/) || t.match(/<meta content="([^"]*)" name="description"/);
      raw = { kind: 'meta', handle: h, desc: m ? m[1] : '', notFound: r2.status === 404 };
    } catch (e) { raw = { kind: 'none', error: String(e) }; }
  }
  if (raw && (raw.kind === 'api' || (raw.kind === 'meta' && raw.desc))) { var o = {}; o[key] = { at: Date.now(), raw: raw }; await chrome.storage.local.set(o); }
  return raw;
}
async function api(action, payload) {
  var s = await chrome.storage.local.get('auth'), a = s.auth;
  if (!a || !a.token) return { ok: false, auth: true, error: '영입보드 앱에서 먼저 로그인해 주세요' };
  try {
    var r = await fetch(a.api || DEFAULT_API, { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify({ token: a.token, action: action, payload: payload || {} }) });
    var j = await r.json();
    if (j && j.auth) await chrome.storage.local.remove('auth');
    return j;
  } catch (e) { return { ok: false, error: '서버에 연결하지 못했어요' }; }
}
chrome.runtime.onMessage.addListener(function (m, sender, send) {
  (async function () {
    if (m.t === 'setAuth') { await chrome.storage.local.set({ auth: { token: m.token, me: m.me, api: m.api || DEFAULT_API, app: m.app || DEFAULT_APP } }); return { ok: true }; }
    if (m.t === 'clearAuth') { await chrome.storage.local.remove('auth'); return { ok: true }; }
    if (m.t === 'getAuth') { var s = await chrome.storage.local.get('auth'); return s.auth ? { me: s.auth.me, app: s.auth.app } : null; }
    if (m.t === 'analyze') return await analyze(m.handle);
    if (m.t === 'dmPrepare') { await chrome.storage.local.set({ dm: { handle: String(m.handle || '').toLowerCase(), text: String(m.text || ''), card: m.card || '', owner: m.owner || '', at: Date.now() } }); return { ok: true }; }
    if (m.t === 'dmGet') { var s2 = await chrome.storage.local.get('dm'); var dm = s2.dm; if (!dm || Date.now() - dm.at > 5 * 60e3) return null; return dm; }
    if (m.t === 'dmDone') { await chrome.storage.local.remove('dm'); return { ok: true }; }
    if (m.t === 'cardData') {
      try { var cr = await fetch(m.url); var cb = await cr.blob(); var buf = await cb.arrayBuffer(); var bin = ''; var u8 = new Uint8Array(buf); for (var i = 0; i < u8.length; i += 8192) bin += String.fromCharCode.apply(null, u8.subarray(i, i + 8192)); return { ok: true, data: 'data:image/jpeg;base64,' + btoa(bin) }; } catch (e) { return { ok: false }; }
    }
    if (m.t === 'api') return await api(m.action, m.payload);
    return null;
  })().then(send, function (e) { send({ ok: false, error: String(e) }); });
  return true;
});
chrome.action.onClicked.addListener(async function () { var s = await chrome.storage.local.get('auth'); chrome.tabs.create({ url: (s.auth && s.auth.app) || DEFAULT_APP }); });
