/* ===== VERY LABEL 인플루언서 보드 공용 로직 (서버/미리보기 공용) ===== */
var VL = (function () {
  var FIELDS = ['id','platform','handle','key','name','url','followers','category','contact','owner','status','offer','hook','memo','createdAt','createdBy','updatedAt','updatedBy','lastContactAt','lastContactBy','contactCount','version','bio','dupHits','dupLast','following','posts','engRate','avgLikes','avgComments','lastPost','adCount','acctType','igCategory','extLink','tier','fit','analyzedAt','dateWait','dateProposed','dateResult'];
  var LABELS = ['ID','플랫폼','아이디','중복키(수정금지)','이름/닉네임','링크','팔로워','카테고리','연락처','담당자','상태','제안유형','개인화 한줄','메모','등록일시','등록자','수정일시','수정자','최근연락일시','최근연락자','연락횟수','버전','소개글','중복시도횟수','최근중복시도','팔로잉','게시물수','참여율(%)','평균좋아요','평균댓글','최근게시일','협찬글수','계정유형','인스타카테고리','외부링크','등급','적합도','분석일시','대기일','제안일','결과일(승인/거절)'];
  var MEMBERS = ['유경웅','박하운','염찬웅'];
  var STATUSES = ['대기','제안중','승인','거절'];
  var OLD_STATUS = { '발굴': '대기', '보류': '대기', '제안발송': '제안중', '응답': '제안중', '협의중': '제안중', '확정': '승인' };
  function normStatus(s) { s = str(s); return STATUSES.indexOf(s) >= 0 ? s : (OLD_STATUS[s] || '대기'); }
  function kstDate(iso) { var t = Date.parse(iso); if (!isFinite(t)) t = Date.now(); return new Date(t + 9 * 36e5).toISOString().slice(0, 10); }
  function okDate(d) { d = str(d); return /^\d{4}-\d{2}-\d{2}$/.test(d) ? d : ''; }
  var PLATFORMS = ['인스타그램','유튜브','틱톡','블로그','기타'];
  var CATEGORIES = ['건강/웰니스','다이어트/운동','뷰티','육아/맘','푸드/요리','일상/라이프','기타'];
  var OFFERS = ['제품 협찬','유료 광고','공동구매','장기 앰배서더'];
  var EDITABLE = ['name','url','followers','category','contact','status','offer','hook','memo','dateWait','dateProposed','dateResult'];
  var ANA = ['following','posts','engRate','avgLikes','avgComments','lastPost','adCount','acctType','igCategory','extLink','tier','fit','analyzedAt'];
  var TAKEOVER_DAYS = 14;   // 등록 후 14일간 연락 없는 '발굴' 건은 다른 담당자가 가져올 수 있음
  var RESEND_HOURS = 24;    // 24시간 안에 같은 사람에게 다시 발송 표시하면 막음

  function str(v) { return v == null ? '' : String(v).trim(); }
  function uid() { return 'VL' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2, 6).toUpperCase(); }
  function copy(o) { var n = {}; for (var k in o) n[k] = o[k]; return n; }

  function toNum(v) {
    if (typeof v === 'number') return isFinite(v) ? Math.round(v) : '';
    var s = str(v).toLowerCase().replace(/,/g, '').replace(/\s/g, '');
    if (!s) return '';
    var m = s.match(/^([0-9]*\.?[0-9]+)(만|천|k|m|b|억)?/);
    if (!m) return '';
    var u = { '만': 1e4, '천': 1e3, 'k': 1e3, 'm': 1e6, 'b': 1e9, '억': 1e8 }[m[2]] || 1;
    return Math.round(parseFloat(m[1]) * u);
  }

  function detectPlatform(s) {
    s = str(s);
    for (var i = 0; i < PLATFORMS.length; i++) if (s === PLATFORMS[i]) return s;
    var l = s.toLowerCase();
    if (/insta|인스타|ig/.test(l)) return '인스타그램';
    if (/you|유튜/.test(l)) return '유튜브';
    if (/tik|틱톡/.test(l)) return '틱톡';
    if (/blog|블로그|naver|네이버/.test(l)) return '블로그';
    return '';
  }

  /* 링크나 아이디를 받아 플랫폼 + 아이디 + 중복키로 정규화 */
  function parseAccount(input, hint) {
    var raw = str(input);
    if (!raw) return null;
    var platform = detectPlatform(hint), handle = '', url = '';
    var low = raw.toLowerCase();
    var isUrl = /^https?:\/\//.test(low) || /^(www\.|m\.)?(instagram\.com|youtube\.com|tiktok\.com|blog\.naver\.com|m\.blog\.naver\.com)/.test(low);
    if (!isUrl && (/[\/:]/.test(low) || /^www\./.test(low))) return null;
    if (isUrl) {
      url = /^https?:\/\//.test(raw) ? raw : 'https://' + raw;
      var q = low.match(/blogid=([^&#]+)/);
      var u = low.replace(/^https?:\/\//, '').replace(/^(www\.|m\.)/, '');
      var parts = u.split(/[?#]/)[0].split('/').filter(function (x) { return x; });
      var host = parts[0] || '', p1 = parts[1] || '', p2 = parts[2] || '';
      if (host.indexOf('instagram.com') >= 0) { platform = '인스타그램'; handle = (p1 === 'p' || p1 === 'reel' || p1 === 'stories') ? (p1 === 'stories' ? p2 : '') : p1; }
      else if (host.indexOf('youtube.com') >= 0) { platform = '유튜브'; handle = (p1 === 'channel' || p1 === 'c' || p1 === 'user') ? p2 : p1; }
      else if (host.indexOf('tiktok.com') >= 0) { platform = '틱톡'; handle = p1; }
      else if (host.indexOf('naver.com') >= 0) { platform = '블로그'; handle = q ? q[1] : p1; if (handle === 'postview.naver' || handle === 'postview.nhn') handle = q ? q[1] : ''; }
      else { return null; }
    } else {
      handle = low;
    }
    handle = handle.replace(/^@+/, '').replace(/\/+$/, '').replace(/\s+/g, '').trim();
    try { handle = decodeURIComponent(handle); } catch (e) {}
    if (!handle) return null;
    if (!platform) platform = '인스타그램';
    if (!url) url = buildUrl(platform, handle);
    return { platform: platform, handle: handle, key: platform + ':' + handle, url: url };
  }

  function buildUrl(platform, handle) {
    if (platform === '인스타그램') return 'https://www.instagram.com/' + handle + '/';
    if (platform === '유튜브') return /^uc[a-z0-9_-]{20,}$/.test(handle) ? 'https://www.youtube.com/channel/' + handle : 'https://www.youtube.com/@' + handle;
    if (platform === '틱톡') return 'https://www.tiktok.com/@' + handle;
    if (platform === '블로그') return 'https://blog.naver.com/' + handle;
    return '';
  }

  function normContact(c) {
    c = str(c).toLowerCase();
    if (!c) return '';
    var em = c.match(/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/);
    if (em) return em[0];
    var d = c.replace(/[^0-9]/g, '');
    return d.length >= 9 ? d : '';
  }

  /* 중복 찾기: hard = 같은 플랫폼 같은 아이디(등록 불가), soft = 확인 필요 */
  function findDup(rows, parsed, contact, exceptId) {
    var hard = null, soft = [];
    var nc = normContact(contact);
    for (var i = 0; i < rows.length; i++) {
      var r = rows[i];
      if (r.id === exceptId) continue;
      if (parsed && r.key === parsed.key) { hard = r; break; }
    }
    if (!hard) {
      for (var j = 0; j < rows.length; j++) {
        var x = rows[j];
        if (x.id === exceptId) continue;
        if (parsed && x.handle === parsed.handle && x.platform !== parsed.platform) soft.push({ row: x, reason: '다른 플랫폼에 같은 아이디가 있어요' });
        else if (nc && normContact(x.contact) === nc) soft.push({ row: x, reason: '같은 연락처가 등록돼 있어요' });
      }
    }
    return { hard: hard, soft: soft };
  }

  function makeRow(obj, p, user, now) {
    var owner = MEMBERS.indexOf(str(obj.owner)) >= 0 ? str(obj.owner) : user;
    var cat = str(obj.category);
    var offer = str(obj.offer);
    var r0 = {
      id: uid(), platform: p.platform, handle: p.handle, key: p.key,
      name: str(obj.name), url: str(obj.url) && /^https?:/i.test(str(obj.url)) ? str(obj.url) : p.url,
      followers: toNum(obj.followers), category: cat, contact: str(obj.contact),
      owner: owner, status: normStatus(obj.status),
      offer: offer || '제품 협찬', hook: str(obj.hook), memo: str(obj.memo),
      createdAt: now, createdBy: user, updatedAt: now, updatedBy: user,
      lastContactAt: '', lastContactBy: '', contactCount: 0, version: 1, bio: str(obj.bio).slice(0, 500), dupHits: 0, dupLast: '',
      following: '', posts: '', engRate: '', avgLikes: '', avgComments: '', lastPost: '', adCount: '', acctType: '', igCategory: '', extLink: '', tier: tierOf(toNum(obj.followers)), fit: '', analyzedAt: '',
      dateWait: okDate(obj.dateWait) || kstDate(now), dateProposed: okDate(obj.dateProposed), dateResult: okDate(obj.dateResult)
    };
    if (r0.status === '제안중' && !r0.dateProposed) r0.dateProposed = kstDate(now);
    if ((r0.status === '승인' || r0.status === '거절') && !r0.dateResult) r0.dateResult = kstDate(now);
    ANA.forEach(function (f) { if (obj[f] !== undefined && obj[f] !== null && obj[f] !== '') r0[f] = obj[f]; });
    return r0;
  }

  function find(rows, id) { for (var i = 0; i < rows.length; i++) if (rows[i].id === id) return rows[i]; return null; }
  function label(r) { return (r.platform === '블로그' ? 'blog/' : '@') + r.handle; }

  function add(rows, obj, user, now) {
    var p = parseAccount(obj.account || obj.url, obj.platform);
    if (!p) return { ok: false, error: '아이디 또는 프로필 링크를 입력해 주세요' };
    var d = findDup(rows, p, obj.contact);
    if (d.hard) {
      var ops0 = [];
      if (d.hard.owner !== user) { var hr = copy(d.hard); hr.dupHits = Number(hr.dupHits || 0) + 1; hr.dupLast = user + '|' + now; ops0.push({ t: 'update', row: hr }); }
      return { ok: false, dup: d.hard, ops: ops0, logs: [['중복시도', label(d.hard), d.hard.owner + ' 담당 계정을 ' + user + '님이 등록 시도']], error: '이미 등록된 인플루언서예요 (' + d.hard.owner + ' 담당 · ' + d.hard.status + ')' };
    }
    if (d.soft.length && !obj.force) return { ok: false, needConfirm: true, soft: d.soft, error: '비슷한 항목이 있어요. 확인 후 다시 등록해 주세요' };
    if (!obj.url) obj.url = p.url;
    var row = makeRow(obj, p, user, now);
    return { ok: true, row: row, ops: [{ t: 'append', row: row }], logs: [['등록', label(row), row.owner + ' 담당']] };
  }

  function bulk(rows, list, user, now, owner) {
    var work = rows.slice(), added = [], dups = [], inFile = [], invalid = [], soft = [], seen = {};
    for (var i = 0; i < list.length; i++) {
      var obj = list[i] || {};
      if (owner && !str(obj.owner)) obj.owner = owner;
      var p = parseAccount(obj.account || obj.url, obj.platform);
      if (!p) { invalid.push({ line: obj._line || i + 1, input: str(obj.account || obj.url) }); continue; }
      if (seen[p.key]) { inFile.push({ line: obj._line || i + 1, input: label(p), first: seen[p.key] }); continue; }
      var d = findDup(work, p, obj.contact);
      if (d.hard) { dups.push({ line: obj._line || i + 1, input: label(p), owner: d.hard.owner, status: d.hard.status, mine: d.hard.owner === user }); seen[p.key] = obj._line || i + 1; continue; }
      if (!obj.url) obj.url = p.url;
      var row = makeRow(obj, p, user, now);
      if (d.soft.length) soft.push({ line: obj._line || i + 1, input: label(p), reason: d.soft[0].reason, other: label(d.soft[0].row), owner: d.soft[0].row.owner });
      seen[p.key] = obj._line || i + 1;
      work.push(row); added.push(row);
    }
    var ops = added.length ? [{ t: 'appendMany', rows: added }] : [];
    return { ok: true, added: added, dups: dups, inFile: inFile, invalid: invalid, soft: soft, ops: ops,
      logs: added.length ? [['일괄등록', added.length + '명', '중복 ' + dups.length + ' / 파일내중복 ' + inFile.length]] : [] };
  }

  /* ---- 인스타그램 공개 프로필 정보 파싱 ---- */
  function decodeEnt(s) {
    return String(s || '').replace(/&#x([0-9a-f]+);/gi, function (m, h) { try { return String.fromCodePoint(parseInt(h, 16)); } catch (e) { return ''; } })
      .replace(/&#(\d+);/g, function (m, d) { try { return String.fromCodePoint(Number(d)); } catch (e) { return ''; } })
      .replace(/&quot;/g, '"').replace(/&#039;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
  }
  var CAT_KW = [
    ['육아/맘', /육아|맘스|엄마|아들맘|딸맘|육아스타|아기|키즈|임산부|출산|\bmom\b|mama|baby/i],
    ['다이어트/운동', /다이어트|운동|헬스|필라테스|요가|러닝|마라톤|바디프로필|크로스핏|fitness|gym|workout|pilates|yoga/i],
    ['뷰티', /뷰티|메이크업|화장품|스킨케어|코덕|beauty|makeup|skincare/i],
    ['푸드/요리', /요리|레시피|집밥|맛집|먹스타|베이킹|도시락|food|cook|recipe|baking/i],
    ['건강/웰니스', /건강|웰니스|영양|비건|약사|영양사|한의|자연식|wellness|health|vegan/i],
    ['일상/라이프', /일상|데일리|daily|라이프|lifestyle|여행|travel|패션|fashion|ootd/i]
  ];
  function guessCategory(text) { text = str(text); for (var i = 0; i < CAT_KW.length; i++) if (CAT_KW[i][1].test(text)) return CAT_KW[i][0]; return ''; }
  function parseIgDesc(desc, handle) {
    desc = decodeEnt(desc).replace(/\s+/g, ' ').trim();
    if (!desc) return { ok: false };
    var num = function (re) { var m = desc.match(re); return m ? (m[1] || m[2] || '') : ''; };
    var fol = num(/팔로워\s*([\d.,]+\s*[만천억KMB]?)|([\d.,]+\s*[KMB]?)\s+Followers?/i);
    if (!fol) return { ok: false };
    var fing = num(/팔로잉\s*([\d.,]+\s*[만천KMB]?)|([\d.,]+\s*[KMB]?)\s+Following/i);
    var posts = num(/게시물\s*([\d.,]+\s*[만천KMB]?)|([\d.,]+\s*[KMB]?)\s+Posts?/i);
    var dash = desc.indexOf(' - ');
    var rest = dash >= 0 ? desc.slice(dash + 3) : desc;
    var hm = rest.match(/@([A-Za-z0-9._]+)/);
    var h = hm ? hm[1].toLowerCase() : '';
    if (handle && h && h !== String(handle).toLowerCase()) return { ok: false };
    var name = hm ? rest.slice(0, hm.index).replace(/^See Instagram photos and videos from\s*/i, '').replace(/[\s(]+$/, '').trim() : '';
    var bm = rest.match(/(?:계정|Instagram)\s*[:：]\s*["'“‘]([\s\S]*)["'”’]\s*$/);
    var bio = bm ? str(bm[1]) : '';
    var em = bio.match(/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/);
    return { ok: true, followers: toNum(fol), following: toNum(fing), posts: toNum(posts), name: name, handle: h || String(handle || '').toLowerCase(), bio: bio, email: em ? em[0] : '', category: guessCategory(bio + ' ' + name) };
  }
  function parseIgHtml(html, handle) {
    html = String(html || '');
    var d = (html.match(/<meta content="([^"]*)" name="description"/) || html.match(/<meta name="description" content="([^"]*)"/) || [])[1];
    var res = parseIgDesc(d || '', handle);
    if (!res.ok) { var og = (html.match(/property="og:description" content="([^"]*)"/) || [])[1]; res = parseIgDesc(og || '', handle); }
    return res;
  }
  /* 인스타 프로필 화면 상단 글자에서 정보 읽기 (PC 연동 버튼용) */
  function parseIgHeader(text, handle, exact) {
    text = String(text || '');
    var f = text.match(/팔로워\s*([\d.,]+\s*[만천억KMB]?)/i) || text.match(/([\d.,]+\s*[KMB만천]?)\s*(?:followers|팔로워)/i);
    var fol = exact ? toNum(String(exact).replace(/,/g, '')) : (f ? toNum(f[1]) : '');
    if (fol === '') return { ok: false };
    var lines = text.split('\n').map(function (s) { return s.trim(); }).filter(function (s) { return s; });
    var idx = -1;
    for (var i = 0; i < lines.length; i++) if (/팔로우\s*[\d.,]|[\d.,]+\s*(following|팔로우)|following\s*[\d.,]/i.test(lines[i])) idx = i;
    var skip = /^(팔로우|팔로잉|메시지|게시물|팔로워|follow|following|message|posts?|followers|더 보기|more|번역 보기|see translation|옵션|연락처|contact|email|이메일|[\d.,]+\s*[만천KMB]?)$/i;
    var rest = lines.slice(idx + 1).filter(function (l) { return !skip.test(l) && l.toLowerCase() !== String(handle || '').toLowerCase(); });
    var name = rest[0] || '', bio = rest.slice(1, 8).join(' ').slice(0, 500);
    var em = (bio + ' ' + text).match(/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/);
    return { ok: true, followers: fol, name: name.slice(0, 60), bio: bio, email: em ? em[0] : '', category: guessCategory(bio + ' ' + name) };
  }
  function tierOf(n) { n = Number(n); if (!n) return ''; if (n >= 1e6) return '메가'; if (n >= 1e5) return '매크로'; if (n >= 1e4) return '마이크로'; return '나노'; }
  var FIT_KW = /건강|웰니스|다이어트|운동|필라테스|요가|러닝|육아|아이|엄마|아침|루틴|식단|영양|유기농|비건|주스|착즙|홈카페|클린|자연|면역|피로|눈건강|베리|빌베리|과일|식품|레시피|살림/g;
  var AD_KW = /#?(유료광고|광고|협찬|제품제공|원고료|소정의|sponsored|paidpartnership|\bad\b|공구|공동구매)/i;
  /* 인스타 원본 데이터(확장 프로그램이 가져온 것)를 분석해 DB 항목으로 변환 */
  function analyzeIg(raw) {
    if (!raw) return { ok: false };
    var now = new Date().toISOString();
    if (raw.kind === 'meta') {
      var m = parseIgDesc(raw.desc || '', raw.handle);
      if (!m.ok) return { ok: false, reason: raw.notFound ? 'notfound' : 'nodata' };
      var fitN0 = ((m.bio + ' ' + m.name).match(FIT_KW) || []).length;
      return { ok: true, source: 'meta', followers: m.followers, following: m.following, posts: m.posts, name: m.name, bio: m.bio, email: m.email, category: m.category, tier: tierOf(m.followers), fit: fitN0 >= 3 ? '높음' : fitN0 >= 1 ? '보통' : '낮음', analyzedAt: now };
    }
    if (raw.kind !== 'api' || !raw.user) return { ok: false, reason: raw.notFound ? 'notfound' : (raw.limited ? 'limited' : 'nodata') };
    var u = raw.user, items = u.items || [];
    var fol = Number(u.followers) || 0;
    var likes = items.map(function (x) { return Number(x.likes) || 0; }), coms = items.map(function (x) { return Number(x.comments) || 0; });
    var sum = function (a) { return a.reduce(function (s, v) { return s + v; }, 0); };
    var avgL = items.length ? Math.round(sum(likes) / items.length) : '', avgC = items.length ? Math.round(sum(coms) / items.length) : '';
    var eng = (items.length && fol) ? Math.round((avgL + avgC) / fol * 10000) / 100 : '';
    var ts = items.map(function (x) { return Number(x.ts) || 0; }).filter(function (v) { return v; }).sort(function (a, b) { return b - a; });
    var lastPost = ts.length ? new Date(ts[0] * 1000).toISOString() : '';
    var caps = items.map(function (x) { return str(x.caption); }).join(' \n ');
    var ads = items.filter(function (x) { return x.paid || AD_KW.test(str(x.caption)); }).length;
    var bio = str(u.bio), name = str(u.name);
    var em = bio.match(/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/);
    var fitN = ((bio + ' ' + name + ' ' + caps).match(FIT_KW) || []).length;
    var type = u.isPrivate ? '비공개' : (u.isBusiness ? '비즈니스' : (u.isProfessional ? '크리에이터' : '개인'));
    if (u.isVerified) type += '·인증';
    return {
      ok: true, source: 'api', followers: fol, following: Number(u.following) || '', posts: Number(u.posts) || '', name: name, bio: bio,
      email: str(u.email) || (em ? em[0] : ''), phone: str(u.phone), category: guessCategory(str(u.category) + ' ' + bio + ' ' + name + ' ' + caps.slice(0, 1500)),
      igCategory: str(u.category), extLink: str(u.ext), acctType: type, avgLikes: avgL, avgComments: avgC, engRate: eng, lastPost: lastPost, adCount: items.length ? ads : '',
      tier: tierOf(fol), fit: fitN >= 6 ? '높음' : fitN >= 2 ? '보통' : '낮음', analyzedAt: now
    };
  }
  function cleanInfo(x) {
    if (!x || !x.ok) return { ok: false };
    var o = { ok: true, followers: toNum(x.followers), name: str(x.name).slice(0, 60), bio: str(x.bio).slice(0, 500), email: str(x.email).slice(0, 80), phone: str(x.phone).slice(0, 30), category: CATEGORIES.indexOf(str(x.category)) >= 0 ? str(x.category) : '' };
    ['following', 'posts', 'avgLikes', 'avgComments', 'adCount'].forEach(function (f) { o[f] = toNum(x[f]); });
    o.engRate = (x.engRate === '' || x.engRate == null || isNaN(Number(x.engRate))) ? '' : Math.round(Number(x.engRate) * 100) / 100;
    ['lastPost', 'acctType', 'igCategory', 'extLink', 'fit', 'analyzedAt'].forEach(function (f) { o[f] = str(x[f]).slice(0, 200); });
    o.tier = tierOf(o.followers);
    return o;
  }
  /* 자동 수집 정보로 빈 칸 채우기 (사람이 입력한 값은 덮어쓰지 않음, 팔로워는 최신값) */
  function mergeInfo(obj, info) {
    if (!info || !info.ok) return obj;
    if (!str(obj.name)) obj.name = info.name;
    if (info.followers !== '' && info.followers != null) obj.followers = info.followers;
    if (!str(obj.category) && info.category) obj.category = info.category;
    if (!str(obj.contact) && info.email) obj.contact = info.email;
    if (!str(obj.bio)) obj.bio = info.bio;
    if (!str(obj.contact) && info.phone) obj.contact = info.phone;
    ANA.forEach(function (f) { if (info[f] !== undefined && info[f] !== '') obj[f] = info[f]; });
    return obj;
  }
  function refresh(rows, id, info, user, now) {
    var r = find(rows, id);
    if (!r) return { ok: false, error: '없는 항목이에요' };
    if (!info || !info.ok) return { ok: false, error: '인스타그램에서 정보를 가져오지 못했어요. 잠시 후 다시 시도해 주세요' };
    var nr = copy(r);
    if (info.followers !== '') nr.followers = info.followers;
    if (!nr.name) nr.name = info.name;
    if (!nr.category && info.category) nr.category = info.category;
    if (!nr.contact && info.email) nr.contact = info.email;
    if (info.bio) nr.bio = info.bio;
    if (!nr.contact && info.phone) nr.contact = info.phone;
    ANA.forEach(function (f) { if (info[f] !== undefined && info[f] !== '') nr[f] = info[f]; });
    nr.tier = tierOf(Number(nr.followers));
    nr.updatedAt = now; nr.updatedBy = user; nr.version = Number(r.version || 1) + 1;
    return { ok: true, row: nr, ops: [{ t: 'update', row: nr }], logs: [['정보갱신', label(nr), '팔로워 ' + nr.followers]] };
  }

  function canTakeover(r, now) {
    if (normStatus(r.status) !== '대기' || r.lastContactAt) return false;
    var t = Date.parse(r.createdAt);
    return isFinite(t) && (Date.parse(now) - t) > TAKEOVER_DAYS * 864e5;
  }

  function update(rows, id, patch, version, user, now) {
    var r = find(rows, id);
    if (!r) return { ok: false, error: '삭제됐거나 없는 항목이에요' };
    if (r.owner !== user) return { ok: false, error: r.owner + '님 담당이라 수정할 수 없어요' };
    if (version && Number(version) !== Number(r.version)) return { ok: false, conflict: true, row: r, error: '다른 기기에서 먼저 수정됐어요. 최신 내용으로 바꿨으니 다시 확인해 주세요' };
    var nr = copy(r);
    if (patch.account != null && str(patch.account)) {
      var p = parseAccount(patch.account, patch.platform || r.platform);
      if (!p) return { ok: false, error: '아이디 형식을 확인해 주세요' };
      if (p.key !== r.key) {
        var d = findDup(rows, p, '', id);
        if (d.hard) return { ok: false, dup: d.hard, error: '바꾸려는 아이디는 이미 ' + d.hard.owner + '님이 등록했어요' };
        nr.platform = p.platform; nr.handle = p.handle; nr.key = p.key;
        if (!patch.url) nr.url = p.url;
      }
    }
    for (var i = 0; i < EDITABLE.length; i++) {
      var k = EDITABLE[i];
      if (patch[k] !== undefined) nr[k] = k === 'followers' ? toNum(patch[k]) : (k.indexOf('date') === 0 ? okDate(patch[k]) : str(patch[k]));
    }
    nr.status = normStatus(nr.status);
    var oldSt = normStatus(r.status);
    if (nr.status !== oldSt) {
      if (nr.status === '제안중' && !nr.dateProposed) nr.dateProposed = kstDate(now);
      if ((nr.status === '승인' || nr.status === '거절') && (patch.dateResult === undefined || !okDate(patch.dateResult))) nr.dateResult = okDate(patch.dateResult) || kstDate(now);
    }
    if (!nr.dateWait) nr.dateWait = kstDate(r.createdAt);
    nr.updatedAt = now; nr.updatedBy = user; nr.version = Number(r.version || 1) + 1;
    var detail = oldSt !== nr.status ? (oldSt + ' → ' + nr.status) : '정보 수정';
    return { ok: true, row: nr, ops: [{ t: 'update', row: nr }], logs: [['수정', label(nr), detail]] };
  }

  function transfer(rows, id, to, user, now) {
    var r = find(rows, id);
    if (!r) return { ok: false, error: '없는 항목이에요' };
    if (MEMBERS.indexOf(to) < 0) return { ok: false, error: '담당자를 선택해 주세요' };
    if (r.owner === to) return { ok: false, error: '이미 ' + to + '님 담당이에요' };
    var allowed = r.owner === user || (to === user && canTakeover(r, now));
    if (!allowed) return { ok: false, error: r.owner + '님 담당이에요. 담당자만 넘길 수 있어요' };
    var nr = copy(r);
    nr.owner = to; nr.updatedAt = now; nr.updatedBy = user; nr.version = Number(r.version || 1) + 1;
    return { ok: true, row: nr, ops: [{ t: 'update', row: nr }], logs: [['담당변경', label(nr), r.owner + ' → ' + to]] };
  }

  function markSent(rows, ids, user, now, force) {
    var done = [], skipped = [], ops = [];
    for (var i = 0; i < ids.length; i++) {
      var r = find(rows, ids[i]);
      if (!r) continue;
      if (r.owner !== user) { skipped.push({ label: label(r), reason: r.owner + ' 담당' }); continue; }
      var last = Date.parse(r.lastContactAt);
      if (!force && isFinite(last) && (Date.parse(now) - last) < RESEND_HOURS * 36e5) { skipped.push({ label: label(r), reason: '24시간 안에 이미 발송' }); continue; }
      var nr = copy(r);
      nr.status = normStatus(nr.status);
      if (nr.status === '대기') nr.status = '제안중';
      if (!nr.dateProposed) nr.dateProposed = kstDate(now);
      nr.lastContactAt = now; nr.lastContactBy = user;
      nr.contactCount = Number(r.contactCount || 0) + 1;
      nr.updatedAt = now; nr.updatedBy = user; nr.version = Number(r.version || 1) + 1;
      ops.push({ t: 'update', row: nr }); done.push(nr);
    }
    return { ok: true, done: done, skipped: skipped, ops: ops, logs: done.length ? [['발송완료', done.length + '명', done.map(label).join(', ').slice(0, 300)]] : [] };
  }

  function remove(rows, id, user) {
    var r = find(rows, id);
    if (!r) return { ok: false, error: '없는 항목이에요' };
    if (r.owner !== user) return { ok: false, error: r.owner + '님 담당이라 삭제할 수 없어요' };
    return { ok: true, ops: [{ t: 'delete', row: r }], logs: [['삭제', label(r), r.status]] };
  }

  return {
    FIELDS: FIELDS, LABELS: LABELS, MEMBERS: MEMBERS, STATUSES: STATUSES, PLATFORMS: PLATFORMS,
    CATEGORIES: CATEGORIES, OFFERS: OFFERS, TAKEOVER_DAYS: TAKEOVER_DAYS, RESEND_HOURS: RESEND_HOURS,
    parseAccount: parseAccount, findDup: findDup, toNum: toNum, detectPlatform: detectPlatform, label: label,
    canTakeover: canTakeover, normStatus: normStatus, kstDate: kstDate, okDate: okDate, parseIgDesc: parseIgDesc, parseIgHtml: parseIgHtml, guessCategory: guessCategory, analyzeIg: analyzeIg, tierOf: tierOf, ANA: ANA, parseIgHeader: parseIgHeader, cleanInfo: cleanInfo, mergeInfo: mergeInfo, refresh: refresh, normContact: normContact, add: add, bulk: bulk, update: update, transfer: transfer, markSent: markSent, remove: remove
  };
})();
