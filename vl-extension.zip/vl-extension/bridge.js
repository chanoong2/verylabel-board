/* 영입보드 앱 페이지 <-> 확장 연결 */
(function () {
  var ver = chrome.runtime.getManifest().version;
  function hello() { window.postMessage({ type: 'VL_EXT_HELLO', ver: ver }, '*'); }
  window.addEventListener('message', function (e) {
    if (e.source !== window || !e.data || typeof e.data !== 'object') return;
    var d = e.data;
    if (d.type === 'VL_PING') hello();
    if (d.type === 'VL_EXT_REQ' && d.msg) {
      try {
        chrome.runtime.sendMessage(d.msg, function (res) {
          if (chrome.runtime.lastError) res = null;
          if (d.id) window.postMessage({ type: 'VL_EXT_RES', id: d.id, res: res || null }, '*');
        });
      } catch (err) { if (d.id) window.postMessage({ type: 'VL_EXT_RES', id: d.id, res: null }, '*'); }
    }
  });
  document.documentElement.setAttribute('data-vl-ext', ver);
  hello();
  document.addEventListener('DOMContentLoaded', hello);
})();
