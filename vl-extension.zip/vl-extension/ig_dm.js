/* 인스타 DM 화면: 영입보드에서 'DM 보내기'를 누르면 멘트를 입력창에 넣고, 명함 첨부 버튼을 보여줌 (전송은 사용자가 직접) */
(function () {
  if (window.__vlDm) return; window.__vlDm = true;
  function send(m) { return new Promise(function (res) { try { chrome.runtime.sendMessage(m, function (r) { res(chrome.runtime.lastError ? null : r); }); } catch (e) { res(null); } }); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  var busy = false, doneFor = '';
  function box() { return document.querySelector('[role="textbox"][contenteditable="true"]'); }
  function banner(html) {
    var host = document.getElementById('vl-dm-helper');
    if (!host) { host = document.createElement('div'); host.id = 'vl-dm-helper'; host.style.cssText = 'position:fixed;right:18px;bottom:90px;z-index:2147483646;'; host.attachShadow({ mode: 'open' }); document.documentElement.appendChild(host); }
    host.shadowRoot.innerHTML = '<style>*{box-sizing:border-box;font-family:Pretendard,-apple-system,"Malgun Gothic",sans-serif}.p{width:300px;background:#fff;border-radius:14px;box-shadow:0 12px 40px rgba(0,0,0,.25);overflow:hidden;font-size:13.5px;color:#111}.h{background:#293BAC;color:#fff;padding:8px 12px;font-weight:800;display:flex}.h b{font-family:Georgia,serif;margin-right:6px}.h span{margin-left:auto;cursor:pointer}.b{padding:12px;line-height:1.5}.btn{width:100%;margin-top:8px;border:0;border-radius:10px;padding:10px;font-weight:800;cursor:pointer;background:#293BAC;color:#fff;font-size:14px}.btn.g{background:#F1F2F6;color:#111}.mut{color:#5B6170;font-size:12.5px}img{width:100%;border-radius:8px;border:1px solid #eee;margin-top:8px}</style><div class="p"><div class="h"><b>VERY LABEL</b> DM 도우미<span id="x">×</span></div><div class="b">' + html + '</div></div>';
    host.shadowRoot.getElementById('x').onclick = function () { host.remove(); };
    return host.shadowRoot;
  }
  function pasteText(tb, text) {
    tb.focus();
    var dt = new DataTransfer(); dt.setData('text/plain', text);
    tb.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }));
  }
  async function attachCard(dm, root) {
    var b = root.getElementById('att'); b.textContent = '명함 넣는 중...';
    var r = await send({ t: 'cardData', url: dm.card });
    if (!r || !r.ok) { b.textContent = '명함을 못 불러왔어요'; return; }
    var bin = atob(r.data.split(',')[1]), u8 = new Uint8Array(bin.length); for (var i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
    var file = new File([u8], 'VERYLABEL_명함_' + (dm.owner || '') + '.jpg', { type: 'image/jpeg' });
    var tb = box(), dt = new DataTransfer(); dt.items.add(file);
    if (tb) { tb.focus(); tb.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true })); }
    b.textContent = '명함 첨부됨 · 입력창 미리보기를 확인하세요';
  }
  async function check() {
    if (busy || location.pathname.indexOf('/direct/') !== 0) return;
    var dm = await send({ t: 'dmGet' });
    if (!dm || doneFor === dm.at) return;
    var tb = box(); if (!tb) return;
    busy = true; doneFor = dm.at;
    await new Promise(function (r) { setTimeout(r, 600); });
    tb = box();
    if (tb && !tb.innerText.trim()) pasteText(tb, dm.text);
    await send({ t: 'dmDone' });
    var root = banner('<b>@' + esc(dm.handle) + '</b>에게 보낼 멘트를 입력창에 넣었어요.<div class="mut">내용 확인 후 직접 Enter로 보내세요. (자동 전송 안 함)</div>' + (dm.card ? '<img src="' + esc(dm.card) + '"><button class="btn" id="att">명함 이미지도 첨부하기</button>' : '') + '<button class="btn g" id="cl">닫기</button>');
    var at = root.getElementById('att'); if (at) at.onclick = function () { attachCard(dm, root); };
    root.getElementById('cl').onclick = function () { var h = document.getElementById('vl-dm-helper'); if (h) h.remove(); };
    busy = false;
  }
  setInterval(check, 1000);
})();
