/* 인스타그램 프로필 화면에 VL 영입보드 패널 표시 */
(function () {
  if (window.__vlPanel) return; window.__vlPanel = true;
  var RESERVED = /^(p|reel|reels|explore|stories|direct|accounts|tv|about|legal|developer|challenge|emails|session|web|privacy|terms|ar|lite|nametag|oauth|graphql|api|_u)$/i;
  var STAGES = ['대기', '제안중', '승인', '거절'];
  var host = document.createElement('div'); host.id = 'vl-board-panel';
  host.style.cssText = 'position:fixed;right:18px;bottom:18px;z-index:2147483646;';
  var root = host.attachShadow({ mode: 'open' });
  root.innerHTML = '<style>' +
    '*{box-sizing:border-box;font-family:Pretendard,-apple-system,"Malgun Gothic",sans-serif}' +
    '.p{width:320px;background:#fff;border-radius:16px;box-shadow:0 12px 40px rgba(0,0,0,.25);overflow:hidden;color:#111;font-size:13.5px;line-height:1.45}' +
    '.h{background:#293BAC;color:#fff;padding:9px 12px;display:flex;align-items:center;gap:8px;font-weight:800;cursor:pointer}' +
    '.h b{font-family:Georgia,serif;letter-spacing:.04em}.h .x{margin-left:auto;opacity:.8;font-size:16px}' +
    '.b{padding:12px}.big{font-size:16px;font-weight:900;word-break:break-all}.mut{color:#5B6170;font-size:12.5px}' +
    '.ok{background:#E9F8EF;color:#0B6B3A;border-radius:10px;padding:9px 10px;margin-top:8px;font-weight:700}' +
    '.bad{background:#DC2626;color:#fff;border-radius:10px;padding:10px;margin-top:8px}.bad b{font-size:14.5px}' +
    '.mine{background:#EEF1FF;color:#1D2C8A;border-radius:10px;padding:9px 10px;margin-top:8px;font-weight:700}' +
    '.st{display:flex;flex-wrap:wrap;gap:5px;margin-top:8px}.st button{border:1.5px solid #E6E8EE;background:#fff;border-radius:9px;padding:5px 9px;font-weight:700;font-size:12.5px;cursor:pointer}' +
    '.st button.on{background:#293BAC;border-color:#293BAC;color:#fff}' +
    '.btn{width:100%;margin-top:10px;border:0;border-radius:11px;padding:11px;font-weight:800;font-size:14px;background:#293BAC;color:#fff;cursor:pointer}.btn.y{background:#FFE600;color:#111}' +
    '.g{display:grid;grid-template-columns:1fr 1fr;gap:4px 10px;margin-top:8px;font-size:12.5px}.g span{color:#5B6170}.g b{font-weight:800}' +
    '.mini .b{display:none}.spin{display:inline-block;width:12px;height:12px;border:2px solid currentColor;border-right-color:transparent;border-radius:50%;animation:s .7s linear infinite;vertical-align:-1px}@keyframes s{to{transform:rotate(360deg)}}' +
    'a{color:#293BAC;font-weight:700}' +
    '</style><div class="p" id="p"><div class="h" id="hd"><b>VERY LABEL</b> 영입보드<span class="x" id="mn">–</span></div><div class="b" id="bd"></div></div>';
  var P = root.getElementById('p'), BD = root.getElementById('bd');
  root.getElementById('hd').onclick = function () { P.classList.toggle('mini'); root.getElementById('mn').textContent = P.classList.contains('mini') ? '+' : '–'; };
  function send(m) { return new Promise(function (res) { try { chrome.runtime.sendMessage(m, function (r) { res(chrome.runtime.lastError ? null : r); }); } catch (e) { res(null); } }); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function fmt(n) { n = Number(n); if (!n && n !== 0) return '-'; if (n >= 1e8) return (n / 1e8).toFixed(1).replace(/\.0$/, '') + '억'; if (n >= 1e4) return (n / 1e4).toFixed(n >= 1e5 ? 0 : 1).replace(/\.0$/, '') + '만'; if (n >= 1e3) return (n / 1e3).toFixed(1).replace(/\.0$/, '') + '천'; return String(n); }
  function d(iso) { if (!iso) return '-'; var t = new Date(iso); return (t.getMonth() + 1) + '/' + t.getDate(); }
  var cur = '', busy = false, auth = null;
  function handleNow() { var h = (location.pathname.split('/').filter(Boolean)[0] || '').toLowerCase(); return (h && !RESERVED.test(h) && /^[a-z0-9._]{1,30}$/.test(h)) ? h : ''; }
  function stats(r) {
    return '<div class="g"><span>팔로워</span><b>' + fmt(r.followers) + '</b><span>카테고리</span><b>' + esc(r.category || '-') + '</b>' +
      (r.engRate !== '' && r.engRate != null ? '<span>참여율</span><b>' + r.engRate + '%</b>' : '') + (r.avgLikes ? '<span>평균 좋아요</span><b>' + fmt(r.avgLikes) + '</b>' : '') +
      (r.lastPost ? '<span>최근 게시</span><b>' + d(r.lastPost) + '</b>' : '') + (r.adCount !== '' && r.adCount != null ? '<span>최근 협찬글</span><b>' + r.adCount + '개</b>' : '') +
      (r.fit ? '<span>베리라벨 적합도</span><b>' + esc(r.fit) + '</b>' : '') + (r.contact ? '<span>연락처</span><b style="word-break:break-all">' + esc(r.contact) + '</b>' : '') + '</div>';
  }
  function stageRow(r) {
    var L = { '대기': '① 대기', '제안중': '② 제안중', '승인': '③ 승인', '거절': '거절' };
    return '<div class="mut" style="margin-top:10px">제안 단계' + (r.status === '제안중' && r.dateProposed ? ' · 제안일 ' + r.dateProposed : '') + ((r.status === '승인' || r.status === '거절') && r.dateResult ? ' · ' + r.dateResult : '') + '</div><div class="st">' + STAGES.map(function (s) { return '<button data-s="' + s + '"' + (s === VL.normStatus(r.status) ? ' class="on"' : '') + '>' + L[s] + '</button>'; }).join('') + '</div>';
  }
  function bindStages(r) {
    root.querySelectorAll('.st button').forEach(function (b) {
      b.onclick = async function () {
        if (busy) return; busy = true; b.innerHTML = '<span class="spin"></span>';
        var res = await send({ t: 'api', action: 'update', payload: { id: r.id, version: r.version, patch: { status: b.dataset.s } } });
        busy = false;
        if (res && res.ok && res.data && res.data.ok) render(res.data.row, true); else { alert((res && (res.error || (res.data && res.data.error))) || '저장 실패'); load(true); }
      };
    });
  }
  function render(r, saved) {
    var mine = auth && r.owner === auth.me;
    BD.innerHTML = '<div class="big">@' + esc(r.handle) + '</div><div class="mut">' + esc(r.name || '') + '</div>' +
      (mine ? '<div class="mine">' + (saved ? '저장됨 · ' : '') + '내 담당 · ' + esc(r.status) + '</div>' :
        '<div class="bad"><b>이미 등록된 인플루언서</b><br>' + esc(r.owner) + ' 담당 · ' + esc(r.status) + ' · 최근 연락 ' + d(r.lastContactAt) + '<br>중복 연락하지 마세요</div>') +
      stats(r) + (mine ? stageRow(r) : '') + '<button class="btn" id="ref">' + (mine ? '최신 정보로 다시 분석' : '정보만 최신으로 갱신') + '</button>';
    if (mine) bindStages(r);
    root.getElementById('ref').onclick = async function () {
      this.innerHTML = '<span class="spin"></span> 분석 중';
      var raw = await send({ t: 'analyze', handle: r.handle }), info = VL.analyzeIg(raw);
      if (!info.ok) { this.textContent = '분석 실패 (잠시 후 다시)'; return; }
      var res = await send({ t: 'api', action: 'refresh', payload: { id: r.id, account: r.url || r.handle, hintInfo: info } });
      if (res && res.ok && res.data && res.data.ok) render(res.data.row, true); else this.textContent = '갱신 실패';
    };
  }
  async function load(force) {
    var h = handleNow();
    if (!h) { host.style.display = 'none'; cur = ''; return; }
    if (h === cur && !force) return;
    cur = h; host.style.display = 'block';
    auth = await send({ t: 'getAuth' });
    if (!auth) { BD.innerHTML = '<div class="big">@' + esc(h) + '</div><div class="mut" style="margin-top:6px">영입보드 앱에서 로그인하면 여기서 바로 등록·중복 확인이 돼요.</div><a href="https://chanoong2.github.io/verylabel-board/" target="_blank">영입보드 앱 열기</a>'; return; }
    BD.innerHTML = '<div class="big">@' + esc(h) + '</div><div class="mut"><span class="spin"></span> 영입보드에서 확인 중</div>';
    var res = await send({ t: 'api', action: 'check', payload: { handles: [h] } });
    if (h !== cur) return;
    if (!res || !res.ok) { BD.innerHTML = '<div class="big">@' + esc(h) + '</div><div class="mut">' + esc((res && res.error) || '연결 실패') + '</div>'; if (res && res.auth) auth = null; return; }
    var r = res.data.found[h];
    if (r) return render(r);
    BD.innerHTML = '<div class="big">@' + esc(h) + '</div><div class="ok">등록 가능 · 아직 아무도 등록 안 했어요</div><button class="btn" id="add">내 담당으로 등록 (' + esc(auth.me) + ')</button><div class="mut" style="margin-top:6px">팔로워·카테고리·참여율·연락처를 자동으로 분석해서 넣어요.</div>';
    root.getElementById('add').onclick = async function () {
      if (busy) return; busy = true; this.innerHTML = '<span class="spin"></span> 분석하고 등록하는 중';
      var raw = await send({ t: 'analyze', handle: h }), info = VL.analyzeIg(raw);
      var out = await send({ t: 'api', action: 'quickAdd', payload: { account: 'https://www.instagram.com/' + h + '/', platform: '인스타그램', url: 'https://www.instagram.com/' + h + '/', hintInfo: info.ok ? info : null } });
      busy = false;
      if (out && out.ok && out.data) { if (out.data.ok) render(out.data.row, true); else if (out.data.dup) render(out.data.dup); else BD.insertAdjacentHTML('beforeend', '<div class="bad">' + esc(out.data.error) + '</div>'); }
      else BD.insertAdjacentHTML('beforeend', '<div class="bad">' + esc((out && out.error) || '등록 실패') + '</div>');
    };
  }
  document.documentElement.appendChild(host);
  load();
  var last = location.pathname;
  setInterval(function () { if (location.pathname !== last) { last = location.pathname; load(); } }, 700);
})();
